<?php
include_once ("includes/header.php");
include_once ("includes/db.php");
?>
<title></title>
<div class="art-layout-wrapper">
    <div class="art-content-layout">
        <div class="art-content-layout-row">
            <div class="art-layout-cell art-sidebar1"><div class="art-vmenublock clearfix">
                    <div class="art-vmenublockheader">
                        <h3 class="t">BMCC</h3>
                    </div>
                    <div class="art-vmenublockcontent">
                        <ul class="art-vmenu"><li><a href="index.php" class="active">Home</a></li><li><a href="signin.php">Login</a></li><li><a href="signup.php">SignUp</a></li></ul>

                    </div>
                </div><div class="art-block clearfix">
                    <div class="art-blockheader">
                        <h3 class="t">Contact us</h3>
                    </div>
                    <div class="art-blockcontent"><p style="text-align: left;"><img width="50" height="50" alt="" src="images/rss.png">&nbsp;&nbsp;<img width="50" height="50" alt="" src="images/twitter.png">&nbsp;&nbsp;<img width="50" height="50" alt="" src="images/facebook.png" class=""><br></p></div>
                </div></div>
            <div class="art-layout-cell art-content"><article class="art-post art-article">
                    <h2 class="art-postheader">Check  the statue of you login</h2>

                    <div class="art-postcontent art-postcontent-0 clearfix">

                        <p>


<?php
if (session_status() == PHP_SESSION_NONE) {
session_start();
}

$cartamount=0;
if(isset($_POST['cartamount']))
{
 $cartamount =$_POST['cartamount'] ;   
}


$_SESSION['cartamount']=$cartamount;
if (isset($_SESSION['emailaddress']))
{
$email_address=$_SESSION['emailaddress'];
echo "Welcome " . $email_address . ". <br/>";
}
if (isset($_SESSION['password']))
{
$password=$_SESSION['password'];
}
if ((isset($_SESSION['emailaddress']) && $_SESSION['emailaddress'] != "") ||
(isset($_SESSION['password']) && $_SESSION['password'] != "")) {
$sess = session_id();
$query="select * from cart where cart_sess = '$sess'";
$result = mysqli_query($connect, $query) or die(mysql_error());
if(mysqli_num_rows($result)>=1)
{
echo "If you have finished Shopping ";
echo "<a href=shipping_info.php>Click Here</a> to supply Shipping
Information";
echo " Or You can do more purchasing by selecting items from the menu ";
}
else
{
echo "You can do purchasing by selecting items from the menu on left side";
}
}
else
{
?>


<h3>Not Logged in yet</h1>
<p>
You are currently not logged into our system.<br>
You can do purchasing only if you are logged in.<br>
If you have already registered,
<a href="signin.php">click here</a> to login, or if would like to create an
account, <a href="create_account.php">click here</a> to register.
</p>

<?php
}
?>




                        </p>
                    </div>



                </article></div>
        </div>
    </div>
</div>
<?php
include("includes/footer.php");
?>


