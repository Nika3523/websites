<?php
include_once ("includes/header.php");
include_once ("includes/db.php");

?>
<title>Cart</title>
<div class="art-layout-wrapper">
    <div class="art-content-layout">
        <div class="art-content-layout-row">
            <div class="art-layout-cell art-sidebar1"><div class="art-vmenublock clearfix">
                    <div class="art-vmenublockheader">
                        <h3 class="t">BMCC</h3>
                    </div>
                    <div class="art-vmenublockcontent">
                        <ul class="art-vmenu"><li><a href="index.php" class="active">Home</a></li><li><a href="signin.php">Login</a></li><li><a href="signup.php">SignUp</a></li></ul>

                    </div>
                </div><div class="art-block clearfix">
                    <div class="art-blockheader">
                        <h3 class="t">Contact us</h3>
                    </div>
                    <div class="art-blockcontent"><p style="text-align: left;"><img width="50" height="50" alt="" src="images/rss.png">&nbsp;&nbsp;<img width="50" height="50" alt="" src="images/twitter.png">&nbsp;&nbsp;<img width="50" height="50" alt="" src="images/facebook.png" class=""><br></p></div>
                </div></div>
            <div class="art-layout-cell art-content"><article class="art-post art-article">
                    <h2 class="art-postheader">Your Cart</h2>

                    <div class="art-postcontent art-postcontent-0 clearfix">

                        

<?php

if (session_status() == PHP_SESSION_NONE) {
session_start();
}

$message = "";
$quantity="";
$action="";
$query="";
if (isset($_POST['quantity'])) {
$quantity = trim($_POST['quantity']);
}
if ($quantity=='')
{
$quantity=1;
}
if($quantity <=0)
{
echo "Quantity value is invalid ";
echo "Go Back and enter a valid value";
}
else
{
if (isset($_REQUEST['icode'])) {
$itemcode = $_REQUEST['icode'];
}
if (isset($_REQUEST['iname'])) {
$item_name = $_REQUEST['iname'];
}
if (isset($_REQUEST['iprice'])) {
$price = $_REQUEST['iprice'];
}
if (isset($_POST['modified_quantity'])) {
$modified_quantity = $_POST['modified_quantity'];
}
$sess = session_id();
if (isset($_REQUEST['action'])) {
$action = $_REQUEST['action'];
}
switch ($action) {
case "add":
$query="select * from cart where cart_sess = '$sess' and cart_itemcode like
'$itemcode'";
$result = mysqli_query($connect, $query) or die(mysql_error());
if(mysqli_num_rows($result)==1)
{
$row=mysqli_fetch_array($result, MYSQLI_ASSOC);
$qt=$row['cart_quantity'];
$qt=$qt + $quantity;
$query="UPDATE cart set cart_quantity=$qt where cart_sess = '$sess' and
cart_itemcode like '$itemcode'";
$result = mysqli_query($connect, $query) or die(mysql_error());
}
else
{
$query = "INSERT INTO cart (cart_sess, cart_quantity, cart_itemcode,
cart_item_name, cart_price) VALUES ('$sess', $quantity, '$itemcode',
'$item_name', $price)";
$message = "<div align=\"center\"><strong>Item added.</strong></div>";
}
break;
case "change":
if($modified_quantity==0)
{
$query = "DELETE FROM cart WHERE cart_sess = '$sess' and cart_itemcode like
'$itemcode'";
$message = "<div style=\"width:200px; margin:auto;\">Item deleted</div>";
}
else
{
if($modified_quantity <0)
{
echo "Invalid quantity entered";
}
else
{
$query = "UPDATE cart SET cart_quantity = $modified_quantity WHERE cart_sess = '$sess' and cart_itemcode like '$itemcode'";

$message = "<div style=\"width:200px; margin:auto;\">
Quantity changed</div>";
}
}
break;
case "delete":
$query = "DELETE FROM cart WHERE cart_sess = '$sess' and cart_itemcode like'$itemcode'";
$message = "<div style=\"width:200px; margin:auto;\">Item deleted</div>";
break;
case "empty":
$query = "DELETE FROM cart WHERE cart_sess = '$sess'";
break;
}
if($query !="")
{
$results = mysqli_query($connect, $query) or die(mysql_error());
echo $message;
}
include("showcart.php");
echo "<SCRIPT LANGUAGE=\"JavaScript\">updateCart();</SCRIPT>";
}
?>

                       
                    </div>



                </article></div>
        </div>
    </div>
</div>


