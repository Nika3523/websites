-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2018 at 08:22 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `group_project`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `listProduct` ()  BEGIN
select * from products;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectedItem` (IN `item_co` VARCHAR(20))  BEGIN

select * from products where item_code like item_co;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TypeList` ()  BEGIN
select * from group_project.`type`;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_sess` char(50) NOT NULL,
  `cart_itemcode` varchar(20) NOT NULL,
  `cart_quantity` smallint(6) NOT NULL,
  `cart_item_name` varchar(100) DEFAULT NULL,
  `cart_price` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_sess`, `cart_itemcode`, `cart_quantity`, `cart_item_name`, `cart_price`) VALUES
('6u6lqoqlp1li0khsm601vfjv6k', '1', 2, 'test1', '77.00');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_no` int(11) NOT NULL,
  `order_date` date DEFAULT NULL,
  `email_address` varchar(50) DEFAULT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `shipping_address_line1` varchar(255) DEFAULT NULL,
  `shipping_address_line2` varchar(255) DEFAULT NULL,
  `shipping_city` varchar(50) DEFAULT NULL,
  `shipping_state` varchar(50) DEFAULT NULL,
  `shipping_zipcode` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_no`, `order_date`, `email_address`, `customer_name`, `shipping_address_line1`, `shipping_address_line2`, `shipping_city`, `shipping_state`, `shipping_zipcode`) VALUES
(6, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(7, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(8, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(9, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(10, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(11, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(12, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(13, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(14, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(15, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(16, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237'),
(17, '2018-05-21', 'mohamed@hotmail.com', NULL, '1417 Greene Avenue', '2L', 'BROOKLYN', 'NY', '11237');

-- --------------------------------------------------------

--
-- Table structure for table `orders_details`
--

CREATE TABLE `orders_details` (
  `order_no` int(11) NOT NULL,
  `item_code` varchar(20) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` smallint(6) NOT NULL,
  `price` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `order_no` int(6) NOT NULL,
  `order_date` date DEFAULT NULL,
  `amount_paid` decimal(7,2) DEFAULT NULL,
  `email_address` varchar(50) DEFAULT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `payment_type` varchar(20) DEFAULT NULL,
  `name_on_card` varchar(30) DEFAULT NULL,
  `card_number` varchar(20) DEFAULT NULL,
  `expiration_date` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_details`
--

INSERT INTO `payment_details` (`order_no`, `order_date`, `amount_paid`, `email_address`, `customer_name`, `payment_type`, `name_on_card`, `card_number`, `expiration_date`) VALUES
(16, '2018-05-21', '154.00', 'mohamed@hotmail.com', 'MOHAMED IAZA ', NULL, NULL, NULL, NULL),
(17, '2018-05-21', '308.00', 'mohamed@hotmail.com', 'MOHAMED IAZA ', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `person_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `psword` varchar(50) CHARACTER SET utf8 NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `sex` varchar(45) NOT NULL,
  `dob` datetime NOT NULL,
  `street_1` varchar(50) NOT NULL,
  `street_2` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `zip` int(5) NOT NULL,
  `state` varchar(50) NOT NULL,
  `cell_phone` varchar(50) NOT NULL,
  `type_id` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`person_id`, `email`, `psword`, `first_name`, `last_name`, `sex`, `dob`, `street_1`, `street_2`, `city`, `zip`, `state`, `cell_phone`, `type_id`) VALUES
(8, 'mohamed@hotmail.com', '*6BB4837EB74329105EE4568DDA7DC67ED2CA2AD9', 'MOHAMED', 'IAZA', 'Male', '2018-05-09 00:00:00', '1417 Greene Avenue', '2L', 'BROOKLYN', 11237, 'NY', '3479223248', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `item_code` varchar(20) NOT NULL,
  `item_name` varchar(150) NOT NULL,
  `brand_name` varchar(50) NOT NULL,
  `model_number` varchar(30) NOT NULL,
  `description` text,
  `category` varchar(50) DEFAULT NULL,
  `quantity` smallint(6) NOT NULL,
  `price` decimal(7,2) DEFAULT NULL,
  `imagename` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`item_code`, `item_name`, `brand_name`, `model_number`, `description`, `category`, `quantity`, `price`, `imagename`) VALUES
('2', 'Dell spiron', 'Dell ', '7403BLK-PUS In', '7th Generation Intel Core i7-7500U Processor,12GB 2400MHz DDR4', 'PC', 100, '1200.00', 'images/dell1.jpg'),
('3', 'K55', 'CORSAIR', 'K55', 'RGB Gaming Keyboard', 'PC', 100, '60.00', 'images/cors1.jpg'),
('4', ' HARPOON', 'CORSAIR', 'HARPOON_RGB ', 'Gaming Mouse Light weight Design ', 'PC', 100, '60.00', 'images/cormou.jpg'),
('5', '78LMT', 'Gigabyte', ' Motherboard - 78LMT', 'AM3+ / ATX / 4xDDR3/ HDMI/ Realtek ALC892/ 2xPCIE/ 8xUSB 2.0 / 4xUSB3.1 Gen 1/ LAN/ Motherboard ', 'PC', 100, '120.00', 'images/gigamo.jpg'),
('6', 'WD Blue 1TB', 'WD', 'WD10EZEX', 'SATA 6 Gb/s 7200 RPM 64MB Cache 3.5 Inch Desktop Hard Drive ', 'PC', 100, '99.00', 'images/wd.jpg'),
('7', 'Ballistix Sport LT ', 'Ballistix', ' BLS2K4G4D240FSB', ' 8GB Kit (4GBx2) DDR4 2400 MT/s (PC4-19200) DIMM 288-Pin grey', 'PC', 100, '75.00', 'images/ram.jpg'),
('8', 'Accounting All-in-One ', 'Accounting All-in-One For Dummies, with Online Pra', 'ACCBouk', 'Report on financial statements Make savvy business decisions', 'BOOK', 120, '60.00', 'images/account.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `type_id` int(30) NOT NULL,
  `Description` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`type_id`, `Description`) VALUES
(0, 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_no`),
  ADD KEY `email_address` (`email_address`);

--
-- Indexes for table `orders_details`
--
ALTER TABLE `orders_details`
  ADD KEY `order_no` (`order_no`),
  ADD KEY `item_code` (`item_code`);

--
-- Indexes for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD KEY `order_no` (`order_no`),
  ADD KEY `email_address` (`email_address`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`person_id`,`email`),
  ADD KEY `FK_person_type` (`type_id`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`item_code`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `person_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`email_address`) REFERENCES `person` (`email`);

--
-- Constraints for table `orders_details`
--
ALTER TABLE `orders_details`
  ADD CONSTRAINT `orders_details_ibfk_1` FOREIGN KEY (`order_no`) REFERENCES `orders` (`order_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_details_ibfk_2` FOREIGN KEY (`item_code`) REFERENCES `products` (`item_code`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `person`
--
ALTER TABLE `person`
  ADD CONSTRAINT `FK_person_type` FOREIGN KEY (`type_id`) REFERENCES `type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
