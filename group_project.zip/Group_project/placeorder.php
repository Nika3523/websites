


<?php

 include_once("includes/header.php");
    include_once("includes/db.php");
    
    
    ?>

<title>Check out</title>
<div class="art-layout-wrapper">
    <div class="art-content-layout">
        <div class="art-content-layout-row">
            <div class="art-layout-cell art-sidebar1"><div class="art-vmenublock clearfix">
                    <div class="art-vmenublockheader">
                        <h3 class="t">BMCC</h3>
                    </div>
                    <div class="art-vmenublockcontent">
                        <ul class="art-vmenu"><li><a href="index.php" class="active">Home</a></li><li><a href="signin.php">Login</a></li><li><a href="signup.php">SignUp</a></li></ul>

                    </div>
                </div><div class="art-block clearfix">
                    <div class="art-blockheader">
                        <h3 class="t">Contact us</h3>
                    </div>
                    <div class="art-blockcontent"><p style="text-align: left;"><img width="50" height="50" alt="" src="images/rss.png">&nbsp;&nbsp;<img width="50" height="50" alt="" src="images/twitter.png">&nbsp;&nbsp;<img width="50" height="50" alt="" src="images/facebook.png" class=""><br></p></div>
                </div></div>
            <div class="art-layout-cell art-content"><article class="art-post art-article">
                    <h2 class="art-postheader">Check out </h2>

                    <div class="art-postcontent art-postcontent-0 clearfix">

                        <p>
                            <?php
if (session_status() == PHP_SESSION_NONE) {
session_start();
}
if (isset($_SESSION['cartamount']))
{
$cartamount=$_SESSION['cartamount'];
}
$complete_name=$_POST['complete_name'];
$address1 = $_POST['address1'];
$city = $_POST['city'];
$state = $_POST['state'];
$zipcode = $_POST['zipcode'];

$shipping_address_line1 = $_POST['shipping_address_line1'];
$shipping_address_line2 = $_POST['shipping_address_line2'];
$shipping_city = $_POST['shipping_city'];
$shipping_state = $_POST['shipping_state'];
$shipping_zipcode = $_POST['shipping_zipcode'];
$phone_no= $_POST['phone_no'] ;
$_SESSION['complete_name'] =$complete_name;
$_SESSION['address1'] =$address1;
$_SESSION['city'] =$city;
$_SESSION['state'] =$state;
$_SESSION['zipcode'] =$zipcode;

$_SESSION['shipping_address_line1'] =$shipping_address_line1;
$_SESSION['shipping_address_line2'] =$shipping_address_line2;
$_SESSION['shipping_city'] =$shipping_city;
$_SESSION['shipping_state'] =$shipping_state;

$_SESSION['shipping_zipcode'] =$shipping_zipcode;
$_SESSION['phone_no'] =$phone_no;
$email_address= $_SESSION['emailaddress'] ;
$today = date("Y-m-d");
$sessid = session_id();
$sql = "INSERT INTO orders (order_date, email_address,shipping_address_line1, shipping_address_line2, shipping_city, shipping_state, shipping_zipcode) VALUES ('$today','$email_address','$shipping_address_line1','$shipping_address_line2', '$shipping_city','$shipping_state','$shipping_zipcode')";

$result = mysqli_query($connect, $sql) or die(mysqli_error($connect));
$orderid = mysqli_insert_id($connect);

$query = "SELECT * FROM cart WHERE cart_sess='$sessid'";
$results = mysqli_query($connect, $query) or die(mysql_error($connect));
while ($row = mysqli_fetch_array($results, MYSQLI_ASSOC))
{
extract($row);
$totalamount=($cart_price * $cart_quantity);
$sql2 = "INSERT INTO orders_details (order_no, item_code, item_name,quantity, price)VALUES ($orderid,$cart_itemcode,'$cart_item_name',$cart_quantity,$totalamount)";
$insert = mysqli_query($connect, $sql2) or die(mysql_error($connect));
$sql3 = "INSERT INTO payment_details (order_no, email_address,customer_name,order_date,amount_paid)VALUES ($orderid,'$email_address','$complete_name','$today',$totalamount)";
$insertpayment = mysqli_query($connect, $sql3) or die(mysql_error($connect));

}





$query = "DELETE FROM cart WHERE cart_sess='$sessid'";
$delete = mysqli_query($connect, $query) or die(mysql_error());
session_destroy();

echo "Thanks for your Order!";
echo "Please, remember your Order number is $orderid<br>";
include_once("includes/footer.php");
?>

                        </p>
                    </div>



                </article></div>
        </div>
    </div>
</div>



