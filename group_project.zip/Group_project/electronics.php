<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<?php

include ("includes/header.php");
include ("includes/db.php");

function getAllelectronics()
{
    $dbc = getDBC ();
    
    $resultArr = $dbc->query ( "CALL listProduct()" );
    
    $dbc->close ();
    
    return $resultArr;
}

?>
<title>Products</title>
<div class="art-layout-wrapper">
    <div class="art-content-layout">
        <div class="art-content-layout-row">
            <div class="art-layout-cell art-sidebar1"><div class="art-vmenublock clearfix">
                    <div class="art-vmenublockheader">
                        <h3 class="t">BMCC</h3>
                    </div>
                    <div class="art-vmenublockcontent">
                        <ul class="art-vmenu"><li><a href="index.php" class="active">Home</a></li><li><a href="signin.php">Login</a></li><li><a href="signup.php">SignUp</a></li></ul>

                    </div>
                </div><div class="art-block clearfix">
                    <div class="art-blockheader">
                        <h3 class="t">Contact us</h3>
                    </div>
                    <div class="art-blockcontent"><p style="text-align: left;"><img width="50" height="50" alt="" src="images/rss.png">&nbsp;&nbsp;<img width="50" height="50" alt="" src="images/twitter.png">&nbsp;&nbsp;<img width="50" height="50" alt="" src="images/facebook.png" class=""><br></p></div>
                </div></div>
            <div ><article>
                    <h2 class="art-postheader">Products</h2>

                    <div>

                        <p><h4>List of All  our Products </h4>

<?php
if (isset($_SESSION['emailaddress']))
{
   $result = getAllelectronics();
if ($result->num_rows > 0) {
    
     echo '<table class="table table-striped">
            <tr>
                <td><strong>Item Code</strong></td>
                <td><strong>Item name</strong></td>
                <td><strong>model number</strong></td>
                <td valign=\"middle\" align=\"center\"><strong>image</strong></td>
                 <td><strong>Action</strong></td>
            </tr>';
     while ($rows = $result->fetch_assoc()) {
     echo "
            <tr>
                <td>{$rows ['item_code']}</td>
                <td>{$rows ['item_name']}</td>
                <td>{$rows ['model_number']}</td>
                <td valign=\"middle\" align=\"center\"><img src=\"{$rows ['imagename']}\" width=\"200\"></td>
               
                <td>
                    <form action=itemdetails2.php>
                        <input type=hidden name=showRowId value=\"{$rows['item_code']}\" />
                        <button type=submit>Add To Cart</button>
                    </form>
                </td>
            </tr> ";
           
         
        }
        echo '</table>';
        

     
 }
 }


    
    

 else {
    
$result = getAllelectronics();
if ($result->num_rows > 0) {
   
     echo '<table class="table table-striped">
            <tr>
                <td><strong>Item Code</strong></td>
                <td><strong>Item name</strong></td>
                <td><strong>model number</strong></td>
                <td><strong valign=\"middle\" align=\"center\" width=\"200\">image</strong></td>
                
                 <td><strong>Action</strong></td>
            </tr>';
     while ($rows = $result->fetch_assoc()) {

            echo "<tr>
                <td>{$rows ['item_code']}</td>
                <td>{$rows ['item_name']}</td>
                <td>{$rows ['model_number']}</td>
                <td  valign=\"middle\" align=\"center\"><img src=\"{$rows ['imagename']}\" width=\"200\"></td>
               
                <td>
                    <form action=itemdetails.php>
                        <input type=hidden name=showRowId value=\"{$rows ['item_code']}\" />
                        <button type=submit>Details</button>
                    </form>
                </td>
            </tr>";
        
        }

       echo '</table>';
 }
 }
?>

                        </p>
                    </div>



                </article></div>
        </div>
    </div>
</div>
<?php
include("includes/footer.php");
?>
                