<?php
include ("includes/header.php");
include ("includes/db.php");

function SelectedItem($param)
{
    $dbc = getDBC ();
    
    $resultArr = $dbc->query ( "CALL SelectedItem('$param')" );
    
    $dbc->close ();
    
    return $resultArr;
}


?>
<title>electronics</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<div class="art-layout-wrapper">
    <div class="art-content-layout">
        <div class="art-content-layout-row">
            <div class="art-layout-cell art-sidebar1"><div class="art-vmenublock clearfix">
                    <div class="art-vmenublockheader">
                        <h3 class="t">BMCC</h3>
                    </div>
                    <div class="art-vmenublockcontent">
                        <ul class="art-vmenu"><li><a href="index.php" class="active">Home</a></li><li><a href="signin.php">Login</a></li><li><a href="signup.php">SignUp</a></li></ul>

                    </div>
                </div><div class="art-block clearfix">
                    <div class="art-blockheader">
                        <h3 class="t">Contact us</h3>
                    </div>
                    <div class="art-blockcontent"><p style="text-align: left;"><img width="50" height="50" alt="" src="images/rss.png">&nbsp;&nbsp;<img width="50" height="50" alt="" src="images/twitter.png">&nbsp;&nbsp;<img width="50" height="50" alt="" src="images/facebook.png" class=""><br></p></div>
                </div></div>
            <div class="art-layout-cell art-content"><article class="art-post art-article">
                    <h2 class="art-postheader">Products Page</h2>

                    <div class="art-postcontent art-postcontent-0 clearfix">

                        <p><h4>Product Details </h4>

<?php
    
if (isset($_GET['showRowId'])) {

    $rowID = $_GET['showRowId'];
    $query="CALL SelectedItem('$rowID')";
    $results = mysqli_query($connect, $query);
    $row = mysqli_fetch_array($results, MYSQLI_ASSOC);
    extract($row);


//if ($result->num_rows > 0) {
    // echo "is not set";
     echo '<table class=\"table table-striped\">';
            
              
             
                  
                
              
               
     
                
                
                
     

            echo "
               <tr>  <td><strong>Product Code</strong></td> <td>$item_code</td></tr>
                        <tr> <td><strong>Product name</strong></td> <td>$item_name</td></tr>
                     
               <tr><td><strong>Product number</strong> </td><td>$model_number</td></tr>
                   <tr><td><strong>Product brand name</strong></td><td>$brand_name</td></tr>
                          <tr><td><strong>description</strong></td><td>$description</td></tr>
                          <tr><td><strong>price</strong></td><td>$price</td></tr>
                       
              <tr><td><strong>image</strong></td> <td><img src=\"$imagename\"</td></tr>";
               
              
           
          
               echo '</table>' ;
                echo "<form  method= \"post\" action=\"cart.php?action=add&icode=$item_code&iname=$item_name&iprice=$price\">";
              echo'<table>' ;
             
             echo "<tr><td>Quantity:</td><td><input type=\"text\" name=\"quantity\"></td></tr>";
              echo "<tr><td>Price:</td><td>$price</td></tr>";
  echo "<tr><td><input type=\"submit\" name=\"buynow\" value=\"Buy Now\"></td><td><input type=\"submit\"name=\"addtocart\" value=\"Add To Cart\"></td></tr>";


  echo '</table>' ; 


echo" </form>";
                   
         
             
          
        

     
 }
 //}
?>

                        </p>
                    </div>



                </article></div>
        </div>
    </div>
</div>
<?php
include("includes/footer.php");
?>



