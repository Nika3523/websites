<?php

if (session_status() == PHP_SESSION_NONE) { // #1
session_start();
}
?>
<!DOCTYPE html>
<html>
<body>
<?php
$_SESSION["username"] = "John"; // #2
$_SESSION["cartquantity"] = 3;
$_SESSION["cartprice"] = 19.99;
?>
Finished with shopping? <br>
Click <a href="sessionscript2.php"> View Cart </a> link to view the quantity
and amount of the electronics selected in the cart
</body>
</html>