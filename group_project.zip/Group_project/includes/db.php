<?php

global $connect ;
$connect = mysqli_connect("127.0.0.1", "root", "nbuser", "group_project") or
die("Please, check your server connection.");

function getIfSet($fldName) {
    if (isset ( $_REQUEST [$fldName] ))
        return $_REQUEST [$fldName];
    
    return "";
}
function getDBC() {
    $host = "localhost";
    $user = "root";
    $pass = "nbuser";
    $db = "group_project";
    
    $dbc = new mysqli ( $host, $user, $pass, $db );
    
    return $dbc;
}
function getAllType()
{
$dbc = getDBC ();
    
    $resultArr = $dbc->query ( "CALL TypeList()" );
    
 
    
    return $resultArr;
}


?>
