
  <footer class="art-footer">
      <p>Mohamed Ait iaza|Matthew Chin Hing|Nika Ferguson|
Becky Echevarria &nbsp;Copyright © 2018. All Rights Reserved.</p> 

                   
  </footer>

   </div>
   </div>

    </body>
</html>